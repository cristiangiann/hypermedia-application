"use strict";


$(document).ready(function () {
    $("head").append("<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/assets/favicon_io/apple-touch-icon.png\"\>");
    $("head").append("<link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"/assets/favicon_io/favicon-32x32.png\">");
    $("head").append("<link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"/assets/favicon_io/favicon-16x16.png\">");
    $("head").append("<link rel=\"manifest\" href=\"/assets/favicon_io/site.webmanifest\">");
})